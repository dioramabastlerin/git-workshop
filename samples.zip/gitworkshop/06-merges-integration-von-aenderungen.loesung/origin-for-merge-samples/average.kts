if(args.isEmpty())
    throw RuntimeException("No arguments given!")

val s = args.map{ it.toDouble() }.sum()

println("The average is ${s/args.size}")
