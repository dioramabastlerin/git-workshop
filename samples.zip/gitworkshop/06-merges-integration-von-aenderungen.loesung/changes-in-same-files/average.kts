if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| merged common ancestors
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> c593b6022ca04c54771294760be8156f15dffac1

println("The average is ${summe/args.size}")
