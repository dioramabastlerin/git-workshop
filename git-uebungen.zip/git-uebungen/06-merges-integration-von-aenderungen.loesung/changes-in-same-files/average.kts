if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| merged common ancestors
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> 7bbbd41f124064b64d0f6d2ada1fe696f1ebb797

println("The average is ${summe/args.size}")
