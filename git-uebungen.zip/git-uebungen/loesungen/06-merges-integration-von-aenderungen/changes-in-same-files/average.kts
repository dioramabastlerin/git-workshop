if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| d2ecad4
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> dc7f09ae4900e7fb6bd8d2accf79507588c25e80

println("The average is ${summe/args.size}")
