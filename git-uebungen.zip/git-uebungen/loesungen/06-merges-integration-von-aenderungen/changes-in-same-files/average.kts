if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| bc8569d
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> 3c44373f3f3df52812377b0d6100e0ff941e030e

println("The average is ${summe/args.size}")
