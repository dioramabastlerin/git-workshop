if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| 2857e6a
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> 07ce2958ea1d82cea8abf9789a07e31bf82ac1f2

println("The average is ${summe/args.size}")
