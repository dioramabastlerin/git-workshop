---
layout: page
title: <code>zusammenarbeit-rebasing</code>
parent: Lösungen

---
## Lösung zu Schritt 1 - Feature-Branch per Rebase aktualiseren.

Auf dem master gibt es Neuerungen.

Lasse Dir den Commit-Graphen über alle Branches zeigen.

Aktualisiere Deinen Feature-Branch.

Lasse Dir den Commit-Graphen über alle Branches zeigen.


<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* e2f4911 (HEAD -&gt; feature) : Feature weitermachen.<br>* a1a3869 : Feature anfangen.<br>| * 83b652a (master) : Neuerung auf dem master<br>|/  <br>* f89797f Created file bar on branch master by bstachmann.<br>* 7533f15 Created file foo on branch master by bstachmann.<br><br></code></pre>



<pre><code>repo $ <b>git rebase master</b><br><br>Rebasing (1/2)<br>Rebasing (2/2)<br><br>                                                                                <br>Successfully rebased and updated refs/heads/feature.<br><br></code></pre>



<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* a4e199d (HEAD -&gt; feature) : Feature weitermachen.<br>* 21971eb : Feature anfangen.<br>* 83b652a (master) : Neuerung auf dem master<br>* f89797f Created file bar on branch master by bstachmann.<br>* 7533f15 Created file foo on branch master by bstachmann.<br><br></code></pre>


[Zur Aufgabe](aufgabe-zusammenarbeit-rebasing.html){:style="position: fixed; right: 10px; top:60px" .btn .btn-purple}

[Zum Überblick](../../ueberblick.html){:style="position: fixed; right: 10px; top:60px" .btn .btn-purple}

