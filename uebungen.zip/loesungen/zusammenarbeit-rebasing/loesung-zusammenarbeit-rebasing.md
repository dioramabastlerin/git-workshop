---
layout: page
title: <code>zusammenarbeit-rebasing</code>
parent: Lösungen

---
## Lösung zu Schritt 1 - Feature-Branch per Rebase aktualiseren.

Auf dem master gibt es Neuerungen.

Lasse Dir den Commit-Graphen über alle Branches zeigen.

Aktualisiere Deinen Feature-Branch.

Lasse Dir den Commit-Graphen über alle Branches zeigen.


<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* feb0be2 (HEAD -&gt; feature) : Feature weitermachen.<br>* e2cb042 : Feature anfangen.<br>| * 662965d (master) : Neuerung auf dem master<br>|/  <br>* e7a7c28 Created file bar on branch master by bstachmann.<br>* f883f40 Created file foo on branch master by bstachmann.<br><br></code></pre>



<pre><code>repo $ <b>git rebase master</b><br><br>Rebasing (1/2)<br>Rebasing (2/2)<br><br>                                                                                <br>Successfully rebased and updated refs/heads/feature.<br><br></code></pre>



<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* 87f99a1 (HEAD -&gt; feature) : Feature weitermachen.<br>* d13f3db : Feature anfangen.<br>* 662965d (master) : Neuerung auf dem master<br>* e7a7c28 Created file bar on branch master by bstachmann.<br>* f883f40 Created file foo on branch master by bstachmann.<br><br></code></pre>


[Zur Aufgabe](aufgabe-zusammenarbeit-rebasing.html){:style="position: fixed; right: 10px; top:60px" .btn .btn-purple}

[Zum Überblick](../../ueberblick.html){:style="visibility: hidden"}

