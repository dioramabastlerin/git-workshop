---
layout: page
title: <code>zusammenarbeit-rebasing</code>
parent: Lösungen

---
## Lösung zu Schritt 1 - Feature-Branch per Rebase aktualiseren.

Auf dem master gibt es Neuerungen.

Lasse Dir den Commit-Graphen über alle Branches zeigen.

Aktualisiere Deinen Feature-Branch.

Lasse Dir den Commit-Graphen über alle Branches zeigen.


<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* 7c97004 (HEAD -&gt; feature) : Feature weitermachen.<br>* 0e003d5 : Feature anfangen.<br>| * 65f8e8f (master) : Neuerung auf dem master<br>|/  <br>* 3c875e7 Created file bar on branch master by bstachmann.<br>* e1c0021 Created file foo on branch master by bstachmann.<br><br></code></pre>



<pre><code>repo $ <b>git rebase master</b><br><br>Rebasing (1/2)<br>Rebasing (2/2)<br><br>                                                                                <br>Successfully rebased and updated refs/heads/feature.<br><br></code></pre>



<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* d4f1807 (HEAD -&gt; feature) : Feature weitermachen.<br>* 92d5023 : Feature anfangen.<br>* 65f8e8f (master) : Neuerung auf dem master<br>* 3c875e7 Created file bar on branch master by bstachmann.<br>* e1c0021 Created file foo on branch master by bstachmann.<br><br></code></pre>


[Zur Aufgabe](aufgabe-zusammenarbeit-rebasing.md){:style="position: fixed; right: 10px; top:60px" .btn .btn-purple}

