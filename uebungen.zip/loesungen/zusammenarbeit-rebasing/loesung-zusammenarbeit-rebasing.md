---
layout: page
title: <code>zusammenarbeit-rebasing</code>
parent: Lösungen

---
## Lösung zu Schritt 1 - Feature-Branch per Rebase aktualiseren.

Auf dem master gibt es Neuerungen.

Lasse Dir den Commit-Graphen über alle Branches zeigen.

Aktualisiere Deinen Feature-Branch.

Lasse Dir den Commit-Graphen über alle Branches zeigen.


<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* 1743adc (master) : Neuerung auf dem master<br>| * 16353a7 (HEAD -&gt; feature) : Feature weitermachen.<br>| * 25622b1 : Feature anfangen.<br>|/  <br>* fdae1f3 Created file bar on branch master by bstachmann.<br>* 606d648 Created file foo on branch master by bstachmann.<br><br></code></pre>



<pre><code>repo $ <b>git rebase master</b><br><br>Rebasing (1/2)<br>Rebasing (2/2)<br><br>                                                                                <br>Successfully rebased and updated refs/heads/feature.<br><br></code></pre>



<pre><code>repo $ <b>git log --graph --all --decorate --oneline</b><br><br>* 6b9be94 (HEAD -&gt; feature) : Feature weitermachen.<br>* 740045b : Feature anfangen.<br>* 1743adc (master) : Neuerung auf dem master<br>* fdae1f3 Created file bar on branch master by bstachmann.<br>* 606d648 Created file foo on branch master by bstachmann.<br><br></code></pre>


[Zur Aufgabe](aufgabe-zusammenarbeit-rebasing.md){:style="position: fixed; right: 10px; top:60px" .btn .btn-purple}

