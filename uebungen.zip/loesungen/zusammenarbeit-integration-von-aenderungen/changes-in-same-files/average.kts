if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| ef44ae7
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> 125650f7534011ac5fe192b65f6a9856143ee73c

println("The average is ${summe/args.size}")
