if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| 5f3a85a
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> e816aca4b346e9ee53eb4c1d9bf1242cea80245b

println("The average is ${summe/args.size}")
