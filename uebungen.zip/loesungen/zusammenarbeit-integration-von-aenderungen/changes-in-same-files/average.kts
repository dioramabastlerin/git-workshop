if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| f1b1218
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> 7fa566fd60ebf4cb86be7e2bf546c1cc1eab9198

println("The average is ${summe/args.size}")
