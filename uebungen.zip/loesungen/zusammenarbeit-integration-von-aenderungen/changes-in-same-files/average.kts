if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| 566dedc
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> aa0eac2013ff413bae2d6c5c8619e918a0359abb

println("The average is ${summe/args.size}")
