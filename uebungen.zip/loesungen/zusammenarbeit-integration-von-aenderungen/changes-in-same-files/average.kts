if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
||||||| 6dbe3d6
val s = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> 7a6fba2bcfff58bf6dedeb8a327f806540b9ed33

println("The average is ${summe/args.size}")
