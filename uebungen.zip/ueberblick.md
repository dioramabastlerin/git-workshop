---
layout: page
title: <code>ueberblick.md</code>

---
* [intro-hallo-welt](loesungen/intro-hallo-welt/aufgabe-intro-hallo-welt.html) [Lösung](loesungen/intro-hallo-welt/loesung-intro-hallo-welt.html)

* [repository-untersuchen](loesungen/repository-untersuchen/aufgabe-repository-untersuchen.html) [Lösung](loesungen/repository-untersuchen/loesung-repository-untersuchen.html)

* [repository-klonen](loesungen/repository-klonen/aufgabe-repository-klonen.html) [Lösung](loesungen/repository-klonen/loesung-repository-klonen.html)

* [repository-sparse-checkout](loesungen/repository-sparse-checkout/aufgabe-repository-sparse-checkout.html) [Lösung](loesungen/repository-sparse-checkout/loesung-repository-sparse-checkout.html)

* [commits-erstellen](loesungen/commits-erstellen/aufgabe-commits-erstellen.html) [Lösung](loesungen/commits-erstellen/loesung-commits-erstellen.html)

* [commits-staging](loesungen/commits-staging/aufgabe-commits-staging.html) [Lösung](loesungen/commits-staging/loesung-commits-staging.html)

* [zusammenarbeit-push-fetch-pull](loesungen/zusammenarbeit-push-fetch-pull/aufgabe-zusammenarbeit-push-fetch-pull.html) [Lösung](loesungen/zusammenarbeit-push-fetch-pull/loesung-zusammenarbeit-push-fetch-pull.html)

* [zusammenarbeit-push-rejected](loesungen/zusammenarbeit-push-rejected/aufgabe-zusammenarbeit-push-rejected.html) [Lösung](loesungen/zusammenarbeit-push-rejected/loesung-zusammenarbeit-push-rejected.html)

* [zusammenarbeit-integration-von-aenderungen](loesungen/zusammenarbeit-integration-von-aenderungen/aufgabe-zusammenarbeit-integration-von-aenderungen.html) [Lösung](loesungen/zusammenarbeit-integration-von-aenderungen/loesung-zusammenarbeit-integration-von-aenderungen.html)

* [zusammenarbeit-branching](loesungen/zusammenarbeit-branching/aufgabe-zusammenarbeit-branching.html) [Lösung](loesungen/zusammenarbeit-branching/loesung-zusammenarbeit-branching.html)

* [zusammenarbeit-rebasing](loesungen/zusammenarbeit-rebasing/aufgabe-zusammenarbeit-rebasing.html) [Lösung](loesungen/zusammenarbeit-rebasing/loesung-zusammenarbeit-rebasing.html)

* [modularisierung-submodules-subtrees](loesungen/modularisierung-submodules-subtrees/aufgabe-modularisierung-submodules-subtrees.html) [Lösung](loesungen/modularisierung-submodules-subtrees/loesung-modularisierung-submodules-subtrees.html)

* [modularisierung-repositorys-zusammenfuehren](loesungen/modularisierung-repositorys-zusammenfuehren/aufgabe-modularisierung-repositorys-zusammenfuehren.html) [Lösung](loesungen/modularisierung-repositorys-zusammenfuehren/loesung-modularisierung-repositorys-zusammenfuehren.html)

* [modularisierung-lfs](loesungen/modularisierung-lfs/aufgabe-modularisierung-lfs.html) [Lösung](loesungen/modularisierung-lfs/loesung-modularisierung-lfs.html)

