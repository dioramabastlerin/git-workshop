# Aufgabe 1 - Änderungen holen

Hole die beiden neuen Commits vom `origin`-Repository,
ohne den lokalen `master` zu verändern.

## Lösung

    push-fetch-pull.loesung$ cd mein-klon
    mein-klon$ git fetch
    From /home/bjoern/work/git-workshop.samples/build/gitworkshop/push-fetch-pull.aufgabe/blessed
       66dd2a3..abbf4fe  master     -> origin/master
Die Ausgabe zeigt, dass Änderungen auf dem Branch `master` geholt wurden.

    mein-klon$ git status
    On branch master
    Your branch is behind 'origin/master' by 2 commits, and can be fast-forwarded.
      (use "git pull" to update your local branch)
    
    nothing to commit, working tree clean
    mein-klon$ cd ..
