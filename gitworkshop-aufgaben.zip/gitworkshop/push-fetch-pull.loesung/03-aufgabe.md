# Aufgabe 3 - Änderungen integrieren

Integriere die neuesten Commits vom `origin`-Repository
in den lokalen `master`.

## Lösung

    push-fetch-pull.loesung$ cd mein-klon
    mein-klon$ git pull
    Updating 66dd2a3..abbf4fe
    Fast-forward
     foo | 4 ++--
     1 file changed, 2 insertions(+), 2 deletions(-)
    mein-klon$ git log --graph --oneline
    * abbf4fe `foo`: Second edit after cloning
    * cae4f88 `foo`: First edit after cloning
    * 66dd2a3 `foo`: Initial edit before cloning
    mein-klon$ cd ..
