# Aufgabe 2 - Änderungen untersuchen

Lasse dir den Status zeigen,
und untersuche dann,
welche Commits im `master` des `origin`-Repository vorhanden sind,
welche im lokalen `master` noch nicht integriert wurden..

## Lösung

    push-fetch-pull.loesung$ cd mein-klon
    mein-klon$ git status
    On branch master
    Your branch is behind 'origin/master' by 2 commits, and can be fast-forwarded.
      (use "git pull" to update your local branch)
    
    nothing to commit, working tree clean
Der Status zeigt, dass es im Origin-Repo
(auf dem Branch `master`) zwei Commits gibt,
die wir noch nicht integriert haben.

    mein-klon$ git log master..origin/master
    commit abbf4fe1fab7ea3f65974153ae03b5dfee7308b3
    Author: bstachmann <egal>
    Date:   Sun Jun 23 21:13:24 2019 +0200
    
        `foo`: Second edit after cloning
    
    commit cae4f888d8444eeef2ba49eea1749313560cf603
    Author: bstachmann <egal>
    Date:   Sun Jun 23 21:13:24 2019 +0200
    
        `foo`: First edit after cloning
Die `..`-Notation zeigt genau jene Commits,
die in `origing/master` aber noch nicht in `master` enthalten sind.
Etwas kürzer hätte man hier auch auch `git log ..origin/master` schreiben
könne, da wir `master` ja gerade `HEAD` ist.

    mein-klon$ cd ..
