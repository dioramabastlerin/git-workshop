# Repositorys untersuchen

Im Verzeichnis `repo` wartet ein Git-Projekt darauf,
untersucht zu werden. 

    repository-untersuchen.aufgabe$ cd repo
    repo$ ls -hal
    total 24K
    drwxrwxr-x 4 bjoern bjoern 4,0K Jun 23 21:13 .
    drwxrwxr-x 3 bjoern bjoern 4,0K Jun 23 21:13 ..
    drwxrwxr-x 2 bjoern bjoern 4,0K Jun 23 21:13 foo
    drwxrwxr-x 8 bjoern bjoern 4,0K Jun 23 21:13 .git
    -rw-rw-r-- 1 bjoern bjoern  209 Jun 23 21:13 hallo-welt
    -rw-rw-r-- 1 bjoern bjoern  181 Jun 23 21:13 und-tschuess
    repo$ cd ..
Man sieht: Das Projekt enthält eine Datei, ein normales Unterverzeichnis
und natürlich auch ein `.git`-Verzeichnis, welches das Repository

