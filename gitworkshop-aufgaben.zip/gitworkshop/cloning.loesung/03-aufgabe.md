# Aufgabe 3 - Im Klon arbeiten

Erstelle ein Commit und zeige dann den Status.

## Lösung

    cloning.loesung$ cd myfirstclone
    myfirstclone$ # Change file 'foo' at lines 3..3
    myfirstclone$ git add foo
    myfirstclone$ git commit -m `foo`: edited on `master` foo
    myfirstclone$ git status
    On branch master
    Your branch is ahead of 'origin/master' by 1 commit.
      (use "git push" to publish your local commits)
    
    nothing to commit, working tree clean
    myfirstclone$ cd ..
