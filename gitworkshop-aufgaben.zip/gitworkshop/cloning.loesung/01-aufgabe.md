# Aufgabe 1 - Klon durchführen

Erstelle einen Klon von `myfirstrepo` mit dem Namen `myfirstclone`.

## Lösung

    cloning.loesung$ git clone myfirstrepo myfirstclone
    Cloning into 'myfirstclone'...
    done.
