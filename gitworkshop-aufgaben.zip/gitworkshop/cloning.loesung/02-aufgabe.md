# Aufgabe 2 - Klon untersuchen

Zeige den Origin des Klons `myfirstclone`.
                    `origin` steht in der Regel für jenes Repository,
                    von dem geklont wurde.

## Lösung

    cloning.loesung$ cd myfirstclone
    myfirstclone$ git remote -v
    origin	/home/bjoern/work/git-workshop.samples/build/gitworkshop/cloning.loesung/myfirstrepo (fetch)
    origin	/home/bjoern/work/git-workshop.samples/build/gitworkshop/cloning.loesung/myfirstrepo (push)
    myfirstclone$ cd ..
