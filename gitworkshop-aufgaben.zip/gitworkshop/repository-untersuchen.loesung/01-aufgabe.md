# Aufgabe 1 - Commits ansehen

Sieh Dir die Commits an und lasse dabei Informationen 
zu Branches und Tags mit anzeigen.

## Lösung

    repository-untersuchen.loesung$ cd repo
    repo$ git log --oneline --decorate
    a6a4ba3 (HEAD -> master) `und-tschuess`: edited on `master`
    a5b627a (tag: release1.1) `bar`: edited on `master`
    81cf5a7 `bar`: edited on `master`
    d6ec12a `hallo-welt`: edited on `master`
    832ce90 (tag: release1.0) `bar`: edited on `master`
    db6c7f2 `hallo-welt`: edited on `master`
    repo$ cd ..
