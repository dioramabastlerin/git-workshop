# Aufgabe 2 - Einzelne Commits untersuchen

Zeige Details zur aktuellen Version,
und zur Vorgängerversion des Releases 1.0

## Lösung

    repository-untersuchen.loesung$ cd repo

Hier die aktuelle Version `HEAD`:

    repo$ git show
    commit a6a4ba3758c807d0b558cce30405ce9c1b7e427f
    Author: bstachmann <egal>
    Date:   Sun Jun 23 21:13:24 2019 +0200
    
        `und-tschuess`: edited on `master`
    
    diff --git a/und-tschuess b/und-tschuess
    new file mode 100644
    index 0000000..36fe753
    --- /dev/null
    +++ b/und-tschuess
    @@ -0,0 +1,12 @@
    +line 0 created
    +line 1 created
    +line 2 created
    +line 3 created
    +line 4 created
    +line 5 created
    +line 6 created
    +line 7 created
    +line 8 created
    +line 9 created
    +line 10 created
    +line 11 created
    \ No newline at end of file

Und hier kommt die 1.0:

    repo$ git show release1.0~1
    commit db6c7f22d35819428717bde1ba4eed81887d53ce
    Author: bstachmann <egal>
    Date:   Sun Jun 23 21:13:24 2019 +0200
    
        `hallo-welt`: edited on `master`
    
    diff --git a/hallo-welt b/hallo-welt
    new file mode 100644
    index 0000000..36fe753
    --- /dev/null
    +++ b/hallo-welt
    @@ -0,0 +1,12 @@
    +line 0 created
    +line 1 created
    +line 2 created
    +line 3 created
    +line 4 created
    +line 5 created
    +line 6 created
    +line 7 created
    +line 8 created
    +line 9 created
    +line 10 created
    +line 11 created
    \ No newline at end of file
    repo$ cd ..
