# Aufgabe 1 - Klon durchführen

Erstelle einen Klon von `myfirstrepo` mit dem Namen `myfirstclone`.

