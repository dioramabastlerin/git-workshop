# Klonen von Repositorys

Ein Git-Repository namens `myfirstrepo` wurde bereits erstellt.
Es enthält zwei Commits:

    cloning.aufgabe$ cd myfirstrepo
    myfirstrepo$ git log --oneline
    9f55780 `bar`: edited on `master`
    42743d6 `foo`: edited on `master`
    myfirstrepo$ cd ..
