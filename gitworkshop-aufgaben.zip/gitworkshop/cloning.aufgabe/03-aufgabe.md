# Aufgabe 3 - Im Klon arbeiten

Erstelle ein Commit und zeige dann den Status.

