if(args.isEmpty())
    throw RuntimeException("No arguments given!")

<<<<<<< HEAD
val summe = args.map{ it.toInt() }.sum()
=======
val s = args.map{ it.toDouble() }.sum()
>>>>>>> a5c694e6cb734de1e55053bcf66fa2fc7ad03587

println("The average is ${summe/args.size}")
